// Fact
let
 Source = Csv.Document(File.Contents(DataFolder & "/Fact.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Agency", type text}, {"AgeBand", type text}, {"TenureBand", type text}, {"Location", type text}, {"LocationType", type text}, {"OccupationType", type text}, {"SupervisoryStatus", type text}, {"Headcount", Int64.Type}, {"SalaryTotal", type number}, {"SalaryKnownHeadcount", Int64.Type}, {"TenureTotal", type number}, {"TenureKnownHeadcount", Int64.Type}, {"AgeOrder", Int64.Type}, {"TenureOrder", Int64.Type}}, "en-GB")
in Typed

// Audit
let
 Source = Csv.Document(File.Contents(DataFolder & "/Audit.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Check", type text}, {"Value", Int64.Type}}, "en-GB")
in Typed

// DimAgency
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimAgency.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Agency", type text}}, "en-GB")
in Typed

// DimLocationType
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimLocationType.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"LocationType", type text}}, "en-GB")
in Typed

// DimOccupationType
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimOccupationType.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"OccupationType", type text}}, "en-GB")
in Typed