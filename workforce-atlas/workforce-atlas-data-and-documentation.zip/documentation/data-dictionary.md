# Data dictionary

Fact.csv: 159,995 analytical rows. Empty CSV values are missing, not zero.

| Field | CSV interpretation | Missing values | Definition |
|---|---|---:|---|
| Agency | Text | 0 | Agency classification decoded from the OPM dictionary. |
| AgeBand | Text | 0 | Published age band; no individual age is inferred. |
| TenureBand | Text | 0 | Published length-of-service band. |
| Location | Text | 0 | Duty-station geography decoded from OPM. |
| LocationType | Text | 0 | Published duty-station location classification. |
| OccupationType | Text | 0 | Published occupation classification; report labels Occupation type or Occupation. |
| SupervisoryStatus | Text | 0 | Published supervisory classification. |
| Headcount | Number | 0 | Employment count summed across the grouped source rows. Use SUM, not COUNTROWS, for employees. |
| SalaryTotal | Number | 0 | Sum of published positive salary multiplied by employment weight; numerator, not payroll expense. |
| SalaryKnownHeadcount | Number | 0 | Employment weight with a usable positive published salary. |
| TenureTotal | Number | 0 | Sum of known non-negative service years multiplied by employment weight. |
| TenureKnownHeadcount | Number | 0 | Employment weight with usable non-negative service years. |
| AgeOrder | Number | 0 | Numeric ordering helper for published age-band labels. |
| TenureOrder | Number | 0 | Numeric ordering helper for service-length bands. |

Audit.csv records source and cleaning counts. Dim*.csv files are distinct-value lookup extracts, not additional observations.

The native report queries its prepared Fact table. No claim is made that each supplied lookup CSV is a related model table in the PBIX. See the PBIX for its embedded semantic model.
