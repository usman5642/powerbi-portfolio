# Workforce Atlas

Workforce composition, published pay and coverage. A public-data business intelligence portfolio project by Mohammad Usman Bashir.

![Workforce Atlas overview](screenshots/final-page-1.png)

## Business question

How do published pay and service length vary across workforce groups, and how complete are the underlying values?

## What I built

I built a Power BI report using the September 2024 OPM federal workforce snapshot. I decoded official classification tables and aggregated the source into 159,995 analytical rows while preserving a headcount of 2,313,216. I used headcount-weighted salary and tenure measures with separate coverage denominators, plus a composition tree and agency comparison scatterplot.

The report includes an overview, a comparison page, a data-quality and definitions page, and an interactive diagnostic page. The current native report is in [report/Workforce Atlas.pbix](report/Workforce%20Atlas.pbix). The [PDF](report/Workforce%20Atlas.pdf) and PNGs are static previews exported from that saved report on 14 November 2026.

## Data and analytical choices

Scope: **2,313,216 employees represented in 159,995 analytical rows**. See [methodology](documentation/methodology.txt), [field dictionary](documentation/data-dictionary.md) and [source attribution](../SOURCES.md).

The public source records were prepared with Python/pandas and Power Query. Missing values are handled according to their meaning, rather than replaced universally with zero. Measures use the analytical grain and denominators described in the methodology page.

The live visuals reference the prepared Fact table. Supplied dimension CSVs are convenient lookup extracts; their presence does not imply an implemented relationship or a separate star schema in the exported report. The native semantic model is embedded in the PBIX. The readable DAX and Power Query files are implementation references, not a fresh text export of that embedded model.

## Interactions

Use the overview slicer to compare groups. Select chart marks to explore relationships, hover for full category labels and values, and use the page navigation to inspect the detailed comparisons. Service and Workforce include expandable decomposition trees. Learning includes a selectable cohort heatmap. Reset to default restores the saved view.

Comparison tables retain vertical scrolling for their full detail. Long source labels in compact charts may be abbreviated by Power BI; hover or use Focus mode to read the full label. PDF and PNG previews cannot preserve those interactions.

## Validation

The [validation record](../qa/VALIDATION.md) distinguishes checks run in Power BI from independent calculations. Re-run the supplied checks with `python scripts/verify_release.py` from the repository root. The final PBIX is a native service download with embedded data; it has not been opened in Power BI Desktop in this Mac session.

## Interpretation limits

This is one employment snapshot, not hiring or turnover analysis. Published salary is not total compensation. Comparisons are not adjusted for role, grade, seniority or location; unknown salary is excluded, not treated as zero.

## Skills demonstrated

Power BI, DAX, Power Query, weighted measures, data modelling, data-quality reporting.

## Files

- `report/`: final PBIX, PDF and exact readable report definitions extracted from the PBIX.
- `data/`: the cleaned Fact, audit and lookup CSVs.
- `documentation/`: cleaning decisions, field dictionary, SQL checks and measure/query references.
- `screenshots/`: four clean page images from the native PDF export.

These are public-data portfolio analyses, not client deliverables. No commercial outcome, deployed intervention or causal effect is claimed.
