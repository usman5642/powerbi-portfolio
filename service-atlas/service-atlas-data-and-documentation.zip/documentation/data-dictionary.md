# Data dictionary

Fact.csv: 24,918 analytical rows. Empty CSV values are missing, not zero.

| Field | CSV interpretation | Missing values | Definition |
|---|---|---:|---|
| IncidentID | Text | 0 | Anonymised incident identifier; analytical key after selecting its final snapshot. |
| Date | ISO date | 0 | Complaint receipt date or incident opening date, as appropriate to this project. |
| Month | Text | 0 | YYYY-MM derived from Date; chronological grouping label. |
| State | Text | 0 | CFPB state abbreviation for Complaint; final incident state for Service. |
| Priority | Text | 0 | Priority on the selected final incident snapshot, not necessarily intake priority. |
| Channel | Text | 0 | Submission or incident intake channel from the source. |
| Category | Text | 0 | Anonymised incident category on the selected snapshot. |
| AssignmentGroup | Text | 0 | Anonymised assignment group on the selected snapshot; report label Assigned team. |
| Reassignments | Number | 0 | Cumulative reassignment count from the selected event. |
| Reopens | Number | 0 | Cumulative reopen count from the selected event. |
| ResolutionHours | Number | 1,556 | Elapsed calendar hours from opening to resolution. Missing/negative intervals are blank. |
| ReassignedFlag | Number | 0 | 1 when Reassignments is greater than zero. |
| ReopenedFlag | Number | 0 | 1 when Reopens is greater than zero. |
| DurationKnown | Number | 0 | 1 when ResolutionHours is non-null and non-negative. |
| DurationBand | Text | 0 | Left-inclusive duration buckets: <4, [4,24), [24,72), [72,168), >=168 hours, plus Unknown. Local CSV punctuation differs from the ASCII display labels in Power Query; thresholds are identical. |

Audit.csv records source and cleaning counts. Dim*.csv files are distinct-value lookup extracts, not additional observations.

The native report queries its prepared Fact table. No claim is made that each supplied lookup CSV is a related model table in the PBIX. See the PBIX for its embedded semantic model.
