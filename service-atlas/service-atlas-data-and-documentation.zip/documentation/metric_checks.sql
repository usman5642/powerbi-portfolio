SELECT COUNT(*) AS Incidents, 1.0*SUM(ReassignedFlag)/COUNT(*) AS ReassignedShare, 1.0*SUM(ReopenedFlag)/COUNT(*) AS ReopenedShare, COUNT(ResolutionHours) AS KnownDurations FROM fact;
