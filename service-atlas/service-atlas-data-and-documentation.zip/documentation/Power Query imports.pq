// Fact
let
 Source = Csv.Document(File.Contents(DataFolder & "/Fact.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"IncidentID", type text}, {"Date", type date}, {"Month", type text}, {"State", type text}, {"Priority", type text}, {"Channel", type text}, {"Category", type text}, {"AssignmentGroup", type text}, {"Reassignments", Int64.Type}, {"Reopens", Int64.Type}, {"ResolutionHours", type number}, {"ReassignedFlag", Int64.Type}, {"ReopenedFlag", Int64.Type}, {"DurationKnown", Int64.Type}, {"DurationBand", type text}}, "en-GB")
in Typed

// Audit
let
 Source = Csv.Document(File.Contents(DataFolder & "/Audit.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Check", type text}, {"Value", Int64.Type}}, "en-GB")
in Typed

// DimPriority
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimPriority.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Priority", type text}}, "en-GB")
in Typed

// DimChannel
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimChannel.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Channel", type text}}, "en-GB")
in Typed

// DimCategory
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimCategory.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Category", type text}}, "en-GB")
in Typed