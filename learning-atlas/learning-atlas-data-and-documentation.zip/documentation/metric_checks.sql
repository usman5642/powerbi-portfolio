SELECT COUNT(*) AS Enrolments, 1.0*SUM(PassFlag)/COUNT(*) AS PassShare, 1.0*SUM(WithdrawalFlag)/COUNT(*) AS WithdrawalShare, 1.0*SUM(ZeroEarlyActivity)/COUNT(*) AS NoActivityShare FROM fact;
