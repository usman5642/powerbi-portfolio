# Data dictionary

Fact.csv: 32,593 analytical rows. Empty CSV values are missing, not zero.

| Field | CSV interpretation | Missing values | Definition |
|---|---|---:|---|
| EnrolmentID | Text | 0 | Composite module, presentation and student identifier; one enrolment, not one person. |
| Module | Text | 0 | OULAD module code. |
| Presentation | Text | 0 | OULAD course presentation code, including year and presentation suffix. |
| Region | Text | 0 | Source regional category for the enrolled student. |
| PriorEducation | Text | 0 | Highest education category from the source. |
| Outcome | Text | 0 | Final outcome: Pass, Distinction, Fail or Withdrawn. |
| PreviousAttempts | Number | 0 | Previous attempts recorded for the enrolment. |
| EarlyClicks | Number | 0 | Sum of recorded VLE clicks on relative days 0–28 inclusive; no matching activity becomes zero. |
| MeanSubmittedScore | Number | 7,057 | Mean valid 0–100, non-banked, non-Exam submitted score per enrolment. Missing remains blank. |
| SubmittedAssessments | Number | 0 | Count of distinct eligible submitted assessments; no eligible submission becomes zero. |
| PassFlag | Number | 0 | 1 for final Pass or Distinction. |
| WithdrawalFlag | Number | 0 | 1 for final Withdrawn. |
| ZeroEarlyActivity | Number | 0 | 1 when EarlyClicks equals zero; not proof that no studying occurred. |

Audit.csv records source and cleaning counts. Dim*.csv files are distinct-value lookup extracts, not additional observations.

The native report queries its prepared Fact table. No claim is made that each supplied lookup CSV is a related model table in the PBIX. See the PBIX for its embedded semantic model.
