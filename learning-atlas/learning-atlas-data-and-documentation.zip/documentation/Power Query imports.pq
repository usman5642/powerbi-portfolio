// Fact
let
 Source = Csv.Document(File.Contents(DataFolder & "/Fact.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"EnrolmentID", type text}, {"Module", type text}, {"Presentation", type text}, {"Region", type text}, {"PriorEducation", type text}, {"Outcome", type text}, {"PreviousAttempts", Int64.Type}, {"EarlyClicks", Int64.Type}, {"MeanSubmittedScore", type number}, {"SubmittedAssessments", Int64.Type}, {"PassFlag", Int64.Type}, {"WithdrawalFlag", Int64.Type}, {"ZeroEarlyActivity", Int64.Type}}, "en-GB")
in Typed

// Audit
let
 Source = Csv.Document(File.Contents(DataFolder & "/Audit.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Check", type text}, {"Value", Int64.Type}}, "en-GB")
in Typed

// DimModule
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimModule.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Module", type text}}, "en-GB")
in Typed

// DimPresentation
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimPresentation.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Presentation", type text}}, "en-GB")
in Typed

// DimPriorEducation
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimPriorEducation.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"PriorEducation", type text}}, "en-GB")
in Typed