# Validation record

Release date: 14 November 2026. The report files are native downloads from the saved Power BI service reports. Data sources remain pinned to the original downloads recorded in `sources.json`.

## Checks performed

| Area | Evidence |
|---|---|
| Metric reconciliation | `metric-verification.json`: 23 independent calculations against observed Power BI values, including filtered groups and decomposition-tree counts. |
| Source-to-output preparation | `rebuild-verification.json`: source hashes and full-column comparison of rebuilt Fact tables against packaged CSVs. |
| Data validation | `release-verification.json`: analytical-key uniqueness and nulls, lookup coverage, valid duration/score ranges, denominator coverage and the 168-hour boundary. |
| SQL | Four read-only SQL queries executed in temporary in-memory SQLite databases; totals and representative rates reconciled with the analytical data. |
| Native files | PBIX ZIP integrity, embedded DataModel presence, four-page inventories and byte-for-byte equality of the extracted report definitions/resources. |
| Visual exports | All sixteen PDF pages reviewed as PNGs. Four clean page images per project. PDF export is a static preview, not an interactive replacement. |
| Saved online behaviour | Reports saved and reopened during the pass; each overview slicer changed the displayed KPIs and reset restored the default values. Supporting pages were opened during editing and inspected in the native export. |

## Representative interactive cases

| Report | Selection | Observed result |
|---|---|---|
| Complaint | FHA mortgage | 3,650 complaints; 98.8% timely response; 1.3% monetary relief; 0.0 median forwarding days. |
| Service | 1 - Critical | 270 incidents; 80.2 median elapsed hours; 58.5% reassigned; 0.0% reopened. |
| Workforce | Blue Collar | 182,311 headcount; $70,348 average published salary; 9.7 service years; 99.7% salary coverage. |
| Learning | AAA | 748 enrolments; 71.0% pass; 16.8% withdrawal; 3.2% zero early activity. |

The decomposition paths checked during the design work included Service's >=168-hour group (5,361 incidents; 4,983 Moderate) and Workforce's Blue Collar, age 40–44 group (22,588). The independent script repeats those calculations.

## Presentation corrections

- Consistent Arial report theme and 24-point bold main/supporting headings, with shorter explanatory notes.
- Learning enrolment cards use thousands separators.
- Workforce salary chart labels and axes use $K consistently.
- Diagnostic button slicers have sufficient room for their labels.
- Service and Workforce trees use compact spacing so the visible nodes fit.
- Complaint percentage labels were removed from crowded stacked bars; hover retains exact detail.
- Complaint comparison columns fit horizontally. Detail tables intentionally retain vertical scrolling.

Some long source issue names remain abbreviated within compact chart axes/legends. They are available in the native hover text and full data, and the report notes explain how to explore them. No source category was relabelled to imply a different meaning.

## Limits of this verification

The native reports were tested in the Power BI service. Power BI Desktop was not available in this Mac session, so Desktop reopen, Desktop refresh and PBIP/TMDL round-trip were not executed. The PBIX contains data, but a future refresh can require source credentials or changes if a public endpoint/archive changes. The supplied local CSV query references provide a separate reproducible route; they are not a promise of unattended refresh.

This was not an exhaustive test of every possible slicer combination. Phone layouts, RLS, scheduled refresh, tenant sharing, production deployment and load/performance tests were not part of this release. No public sharing settings were changed.
