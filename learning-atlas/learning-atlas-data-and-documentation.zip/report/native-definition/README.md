# Native report definition

This folder contains the Report/definition and Report/StaticResources entries extracted without editing from the final PBIX in the parent folder. They support version review and visual configuration inspection.

This is not a standalone PBIP project. It does not include an exported TMDL semantic model. Open the PBIX to use the complete native report and embedded data. Do not replace these files with the earlier locally generated report designs.
