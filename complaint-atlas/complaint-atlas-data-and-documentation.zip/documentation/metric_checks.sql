SELECT COUNT(*) AS Complaints, 1.0*SUM(Timely)/SUM(TimelyKnown) AS TimelyRate, 1.0*SUM(MonetaryRelief)/COUNT(*) AS ReliefRate FROM fact;
