// Fact
let
 Source = Csv.Document(File.Contents(DataFolder & "/Fact.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"ComplaintID", Int64.Type}, {"Date", type date}, {"Month", type text}, {"MortgageType", type text}, {"Issue", type text}, {"State", type text}, {"Company", type text}, {"Channel", type text}, {"Response", type text}, {"Timely", Int64.Type}, {"TimelyKnown", Int64.Type}, {"MonetaryRelief", Int64.Type}, {"ForwardingDays", Int64.Type}}, "en-GB")
in Typed

// Audit
let
 Source = Csv.Document(File.Contents(DataFolder & "/Audit.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Check", type text}, {"Value", Int64.Type}}, "en-GB")
in Typed

// DimMortgageType
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimMortgageType.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"MortgageType", type text}}, "en-GB")
in Typed

// DimChannel
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimChannel.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Channel", type text}}, "en-GB")
in Typed

// DimResponse
let
 Source = Csv.Document(File.Contents(DataFolder & "/DimResponse.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
 Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
 Typed = Table.TransformColumnTypes(Headers, {{"Response", type text}}, "en-GB")
in Typed