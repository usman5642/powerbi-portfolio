# Data dictionary

Fact.csv: 21,438 analytical rows. Empty CSV values are missing, not zero.

| Field | CSV interpretation | Missing values | Definition |
|---|---|---:|---|
| ComplaintID | Number | 0 | Public complaint identifier; analytical key. |
| Date | ISO date | 0 | Complaint receipt date or incident opening date, as appropriate to this project. |
| Month | Text | 0 | YYYY-MM derived from Date; chronological grouping label. |
| MortgageType | Text | 0 | Historical CFPB mortgage sub-product label. Missing values retained as Not specified. |
| Issue | Text | 0 | Historical issue category reported by the consumer. |
| State | Text | 0 | CFPB state abbreviation for Complaint; final incident state for Service. |
| Company | Text | 0 | Company named in the public CFPB record; not a client relationship. |
| Channel | Text | 0 | Submission or incident intake channel from the source. |
| Response | Text | 0 | Company response classification in the public record. |
| Timely | Number | 0 | 1 for Yes, otherwise 0. Use with TimelyKnown for response rate. |
| TimelyKnown | Number | 0 | 1 when source timely-response value is Yes or No; rate denominator. |
| MonetaryRelief | Number | 0 | 1 for Closed with monetary relief. Indicates response category, not amount. |
| ForwardingDays | Number | 0 | Non-negative calendar days from receipt to sending to company; invalid values are blank. |

Audit.csv records source and cleaning counts. Dim*.csv files are distinct-value lookup extracts, not additional observations.

The native report queries its prepared Fact table. No claim is made that each supplied lookup CSV is a related model table in the PBIX. See the PBIX for its embedded semantic model.
